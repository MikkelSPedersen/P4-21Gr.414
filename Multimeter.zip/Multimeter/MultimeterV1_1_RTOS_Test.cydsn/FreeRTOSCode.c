/*
 * FreeRTOS V202012.00
 * Copyright (C) 2020 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://www.FreeRTOS.org
 * http://aws.amazon.com/freertos
 *
 * 1 tab == 4 spaces!
 */

#include <device.h>

/* RTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

// OUR includes
#include "I2CDisplay.h"
#include "FreeRTOSCode.h"
#include <math.h>

/* Common Demo includes. */
/* 
#include "serial.h"
#include "BlockQ.h"
#include "blocktim.h"
#include "comtest.h"
#include "countsem.h"
#include "death.h"
#include "dynamic.h"
#include "flash.h"
#include "flop.h"
#include "GenQTest.h"
#include "integer.h"
#include "IntQueue.h"
#include "mevents.h"
#include "partest.h"
#include "PollQ.h"
#include "print.h"
#include "QPeek.h"
#include "semtest.h"
*/
/*---------------------------------------------------------------------------*/

/* The time between cycles of the 'check' functionality (defined within the
tick hook. */
#define mainCHECK_DELAY						( ( TickType_t ) 5000 / portTICK_PERIOD_MS )
#define mainCOM_LED							( 3 )

/* The number of nano seconds between each processor clock. */
#define mainNS_PER_CLOCK ( ( unsigned long ) ( ( 1.0 / ( double ) configCPU_CLOCK_HZ ) * 1000000000.0 ) )


/*---------------------------------------------------------------------------*/

/*
 * Configures the timers and interrupts for the fast interrupt test as
 * described at the top of this file.
 */
// extern void vSetupTimerTest( void );
/*---------------------------------------------------------------------------*/




// Variables
float meas = 0;
float Result = 0;
int Autorange_R_UpperBound = 850;
int Autorange_R_LowerBound = 256;
int Autorange_V_UpperBound = 1000;
int Autorange_V1_LowerBound = 94;
int Autorange_V2_LowerBound = 239;

enum Mode{None = 0, Voltage = 1, Current = 2, Resistance = 4};
enum Autorange{High = 0, Mid = 1, Low = 2};

enum Mode Mode_Current = Current; //Default none
enum Autorange Autorange_Current = Mid;

int Resistor[] = {10000, 1000, 100};
float VoltageScale[] = {68.966, 19.529, 1.945};
int V1 = 1024;
float R5 = 0.390;

int ClearDisplay = 1;

void vTask1( void *pvParameters )
{
(void) pvParameters; //måske ikke bruges?
TickType_t xLastWakeTime, xTimeBefore;
const TickType_t xPeriod = pdUS_TO_TICKS(3000); //31250
xLastWakeTime = xTaskGetTickCount();

    for( ;; )
    {
        vTaskDelayUntil( &xLastWakeTime, xPeriod );
        //Pin_2_Write(!Pin_2_Read());
        //xTimeBefore = xTaskGetTickCount();        
        
        int ADC = ADC_DelSig_GetResult16();
        //DFB_LoadInputValue(DFB_CHANNEL_A, pow(ADC, 2));
        if(ADC == 4096){
            ADC = 4095;
        }
        DFB_LoadInputValue(DFB_CHANNEL_A,(pow(ADC, 2)/2));
        //meas = pow(2920,2);
        
        //Pin_2_Write(!Pin_2_Read());
    }
}

void vTask2( void *pvParameters )
{
(void) pvParameters; //måske ikke bruges?
TickType_t xLastWakeTime;
const TickType_t xPeriod = pdUS_TO_TICKS(3000); //31250
xLastWakeTime = xTaskGetTickCount();

int lastAutoRange = 0;
/* As per most tasks, this task is implemented in an infinite loop. */
    for( ;; )
    {
        vTaskDelayUntil( &xLastWakeTime, xPeriod );
        
        Pin_2_Write(!Pin_2_Read());
        
        //noget kode her
        meas = sqrt(DFB_GetOutputValue(DFB_CHANNEL_B) * 2);
        //meas = DFB_GetOutputValue(DFB_CHANNEL_B)*2;
        meas = (meas / 4.0);
        Autorange_Reg_Write(Autorange_Current);
        
        /*
            OBS: Der kommer nok fejl på autorange grundet DFB-blokken, hvis det sker skal der laves en buffer, 
            så MA-filteret har mulighed for at vise en korrekt værdi inden der skiftes igen!!
        */
        /*
        if(lastAutoRange >= 64){
            if(Mode_Current == Resistance){
                if(meas <= Autorange_R_LowerBound && Autorange_Current != High){
                    Autorange_Current--;
                    Autorange_Reg_Write(Autorange_Current);
                    lastAutoRange = 0;
                }else if(meas >= Autorange_R_UpperBound && Autorange_Current != Low){
                    Autorange_Current++;
                    Autorange_Reg_Write(Autorange_Current);
                    lastAutoRange = 0;
                }  
            }else if(Mode_Current == Voltage){
                if(meas >= Autorange_V_UpperBound && Autorange_Current != High){
                    Autorange_Current--;
                    Autorange_Reg_Write(Autorange_Current);
                    lastAutoRange = 0;
                }else if(meas <= Autorange_V2_LowerBound && Autorange_Current == High){
                    Autorange_Current++;
                    Autorange_Reg_Write(Autorange_Current);
                    lastAutoRange = 0;
                }else if(meas <= Autorange_V1_LowerBound && Autorange_Current == Mid){
                    Autorange_Current++;
                    Autorange_Reg_Write(Autorange_Current);
                    lastAutoRange = 0;
                }
            }
        }
        lastAutoRange++;
        */
        
        switch(Status_Reg_Read()){
            case Voltage:  // Voltage 0x01
                if(Mode_Current != Voltage){
                    Mode_Current = Voltage;
                    ClearDisplay = 1;
                }
                meas = meas * VoltageScale[Autorange_Current];
                break;
            case Current:  // Current 0x02
                if(Mode_Current != Current){
                    Mode_Current = Current;
                    ClearDisplay = 1;
                }
                meas = meas / R5;
                break;
            case Resistance:  // Resistance 0x04
                if(Mode_Current != Resistance){
                    Mode_Current = Resistance;
                    ClearDisplay = 1;
                }
                meas = Resistor[Autorange_Current] * ( (V1 / meas) - 1);
                break;
        }
        
        Result = meas;
        
        Pin_2_Write(!Pin_2_Read());
    }
}

void vTask3( void *pvParameters )
{
(void) pvParameters; //måske ikke bruges?
TickType_t xLastWakeTime;
const TickType_t xPeriod = pdMS_TO_TICKS(1000);
xLastWakeTime = xTaskGetTickCount();

int OLCheck = 0;
    for( ;; )
    {
        vTaskDelayUntil( &xLastWakeTime, xPeriod );
        
        //count = xTaskGetTickCount()- count;
        //Pin_2_Write(!Pin_2_Read());
        
        if(ClearDisplay == 1 || OLCheck == 1){
            LCD_Clear_Display();
            ClearDisplay = 0;
            OLCheck = 0;
        }
        
        if(Mode_Current == Resistance){
            /*if(Result >= 30000){
                LCD_Set_Position(0,0);
                LCD_Write_Symbol(8);
                LCD_Write_Symbol(8);
                LCD_Write_Symbol(8);
                OLCheck = 1;
            }else*/ if((Result / 1000) >= 1){
                //LCD_Draw_Display(Mode_Current, 7, (Result / 1000)); 
                LCD_Draw_Display(Mode_Current, 0, Result);
            }else{
                LCD_Draw_Display(Mode_Current, 0, Result); 
            }
        }else if(Mode_Current == Voltage){
            LCD_Draw_Display(Mode_Current, 0, (Result / 1000));
            //LCD_Draw_Display(Mode_Current, 6, Result);
        }else{
            //LCD_Draw_Display(Mode_Current, 0, (Result / 1000));
            LCD_Draw_Display(Mode_Current, 6, Result);
            
        }
        /*
        int temp = Result;
        LCD_Set_Position(0,0);
        LCD_Write_Number(temp / 65536);
        LCD_Set_Position(1,0);
        LCD_Write_Number(temp);
        */
        
        // 5 = mu
        // 6 = m
        // 7 = k
        /* Debug stuff */
        LCD_Set_Position(1,0);
        //LCD_Write_Digit(Autorange_Current);
                // Serial monitor ting
        //char  time[16] = {""};
        //itoa(count, time, 10);
        //UART_1_PutString(time);
        //UART_1_PutString("\n\r");
        //vTaskDelay(pdMS_TO_TICKS(500)); //500 ms delay tror jeg
        //Pin_2_Write(!Pin_2_Read());
    }
}


void prvHardwareSetup( void )
{
/* Port layer functions that need to be copied into the vector table. */
extern void xPortPendSVHandler( void );
extern void xPortSysTickHandler( void );
extern void vPortSVCHandler( void );
extern cyisraddress CyRamVectors[];

	/* Install the OS Interrupt Handlers. */
	CyRamVectors[ 11 ] = ( cyisraddress ) vPortSVCHandler;
	CyRamVectors[ 14 ] = ( cyisraddress ) xPortPendSVHandler;
	CyRamVectors[ 15 ] = ( cyisraddress ) xPortSysTickHandler;

	/* Start-up the peripherals. */

	/* Enable and clear the LCD Display. */
	/*
    LCD_Character_Display_Start();
	LCD_Character_Display_ClearDisplay();
	LCD_Character_Display_Position( 0, 0 );
	LCD_Character_Display_PrintString( "www.FreeRTOS.org " );
	LCD_Character_Display_Position( 1, 0 );
	LCD_Character_Display_PrintString("CY8C5588AX-060  ");
    */

	/* Start the UART. */
	//UART_1_Start();

	/* Initialise the LEDs. */
	//vParTestInitialise();

	/* Start the PWM modules that drive the IntQueue tests. */
	//High_Frequency_PWM_0_Start();
	//High_Frequency_PWM_1_Start();

	/* Start the timers for the Jitter test. */
	//Timer_20KHz_Start();
	//Timer_48MHz_Start();
}
/*---------------------------------------------------------------------------*/

void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
	/* The stack space has been execeeded for a task, considering allocating more. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*---------------------------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* The heap space has been execeeded. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*---------------------------------------------------------------------------*/

/*
	vStartBlockingQueueTasks( mainBLOCK_Q_PRIORITY );
	vCreateBlockTimeTasks();
	vStartCountingSemaphoreTasks();
	vStartDynamicPriorityTasks();
	vStartMathTasks( mainINTEGER_TASK_PRIORITY );
	vStartGenericQueueTasks( mainGEN_QUEUE_TASK_PRIORITY );
	vStartIntegerMathTasks( mainINTEGER_TASK_PRIORITY );
	vStartPolledQueueTasks( mainQUEUE_POLL_PRIORITY );
	vStartQueuePeekTasks();
	vStartSemaphoreTasks( mainSEM_TEST_PRIORITY );
	vStartLEDFlashTasks( mainFLASH_TEST_TASK_PRIORITY );
	vAltStartComTestTasks( mainCOM_TEST_TASK_PRIORITY, 57600, mainCOM_LED );
	vStartInterruptQueueTasks();
	vSetupTimerTest();
	vCreateSuicidalTasks();
*/
