// Defines

#define LCDadr          0x27
#define I2CInitDelay    1
#define I2CSendDelay    1

// RTOS includes 
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

// Includes
#include "project.h"
#include <math.h>
#include "I2CDisplay.h"

// Prototypes
void LCD_Init();
void LCD_Write_Byte(uint8);
void LCD_Write_Digit(uint8);
void LCD_Write_Number(uint16);
void LCD_Write_Symbol(uint8);
void LCD_Set_Position(uint8 , uint8);
void LCD_Clear_Display();
void LCD_Draw_Display(uint8 , uint8 , float);


void LCD_Init()
{
    CyDelay(50);            
    
    // 4-bit setup sequence:
        // First byte
    LCD_Write_Byte(0x8);    
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x3C);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x3C);
    CyDelay(I2CInitDelay);
    
        // Secound byte
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x3C);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x38);
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x2C);
    CyDelay(I2CInitDelay);
    
        // Third byte
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x2C);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x28);
    LCD_Write_Byte(0x88);
    LCD_Write_Byte(0x88);
    LCD_Write_Byte(0x8C);
    CyDelay(I2CInitDelay);

    // Display size sequence:
    LCD_Write_Byte(0x88);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0xC);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0xC8);
    LCD_Write_Byte(0xC8);
    LCD_Write_Byte(0xCC);
    CyDelay(I2CInitDelay);
    
    // Cursor sequence:
    LCD_Write_Byte(0xC8);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0xC);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x18);
    LCD_Write_Byte(0x18);
    LCD_Write_Byte(0x1C);
    CyDelay(I2CInitDelay);
    
    // Clear display sequence:
    LCD_Write_Byte(0x18);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0xC);
    CyDelay(I2CInitDelay);
    
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x68);
    LCD_Write_Byte(0x68);
    LCD_Write_Byte(0x6C);
    CyDelay(I2CInitDelay);
    
    // Text direction setup:
    LCD_Write_Byte(0x68);
}

void LCD_Write_Byte(uint8 data)
{
    I2C_MasterSendStart(LCDadr, 0);   // Start I2C write with LCD
    I2C_MasterWriteByte(data);        // Send 8-bit datapackage
    I2C_MasterSendStop();             // Stop I2C communication
    vTaskDelay(pdMS_TO_TICKS(I2CSendDelay));
}

void LCD_Write_Digit(uint8 digit)
{
    uint8 data0 = 0;        
    uint8 data1 = 0; 
    
    // Bitshift to provide padding for and add control sequence
    data0 = digit << 4;     
    data0 = data0 | 0x9;
    
    // Bitshift to provide padding for and add control sequence
    data1 = digit << 4;     
    data1 = data1 | 0xD;

    // Select column 3 in Standard character pattern table sequence
    LCD_Write_Byte(0x39);   
    LCD_Write_Byte(0x39);
    LCD_Write_Byte(0x3D);
    LCD_Write_Byte(0x39);
    
    // Select digit row in Standard character pattern table sequence
    LCD_Write_Byte(data0);
    LCD_Write_Byte(data0);
    LCD_Write_Byte(data1);
    LCD_Write_Byte(data0);
}

void LCD_Write_Number(uint16 number)
{
    uint8 data[16];                             
    uint8 numberOfDigits = 0;
    
    if(number == 0)
    {
        LCD_Write_Digit(0);
        return;
    }
    
    while(number != 0)                          // Run while digits left
    {
        data[numberOfDigits] = number % 10;     // Calculate modolus 10 
        number = number - data[numberOfDigits]; // Subtract modoulus 10
        
        if(number !=0)                          // If there are digits left
        {
            number = number / 10;       
            numberOfDigits++;
        }
    }

    for(int8 x = numberOfDigits; x >= 0; x--)   // Run while digits left
        LCD_Write_Digit(data[x]);               // Write to LCD
}

void LCD_Write_Symbol(uint8 symbol)
{
    uint8 data0 = 0;
    uint8 data1 = 0;
    uint8 data2 = 0;
    uint8 data3 = 0;
    

    
    switch(symbol)
    {
    case 0: // SPACE
        data0 = 0x19;
        data1 = 0x1D;
        data2 = 0x19;
        data3 = 0x1D;
    break; 
        
    case 1: // V
        data0 = 0x59;
        data1 = 0x5D;
        data2 = 0x69;
        data3 = 0x6D;
    break;
        
    case 2: // A
        data0 = 0x49;
        data1 = 0x4D;
        data2 = 0x19;
        data3 = 0x1D;
    break;
    
    case 4: // Omega
        data0 = 0xF9;
        data1 = 0xFD;
        data2 = 0x49;
        data3 = 0x4D;
    break;

    case 5: // mu
        data0 = 0xE9;
        data1 = 0xED;
        data2 = 0x49;
        data3 = 0x4D;
    break;
        
    case 6: // m
        data0 = 0x69;
        data1 = 0x6D;
        data2 = 0xD9;
        data3 = 0xDD;
    break;
        
    case 7: // k
        data0 = 0x69;
        data1 = 0x6D;
        data2 = 0xB9;
        data3 = 0xBD;
    break; 
        
    case 8: // ,
        data0 = 0x29;
        data1 = 0x2D;
        data2 = 0xC9;
        data3 = 0xCD;
    break;
        
    case 9: // C
        data0 = 0x49;
        data1 = 0x4D;
        data2 = 0x39;
        data3 = 0x3D;
    break;  
    
    }
    
    // Select column in Standard character pattern table sequence
    LCD_Write_Byte(data0);
    LCD_Write_Byte(data0);
    LCD_Write_Byte(data1);
    LCD_Write_Byte(data0);
    
    // Select row in Standard character pattern table sequence
    LCD_Write_Byte(data2);
    LCD_Write_Byte(data2);
    LCD_Write_Byte(data3);
    LCD_Write_Byte(data2);
}

void LCD_Set_Position(uint8 line, uint8 column)
{
    uint8 line0     = 0;
    uint8 line1     = 0;
    uint8 column0   = 0;
    uint8 column1   = 0;
    
    // Select line based on parameter
    if(line == 0)
    {
        line0 = 0x88;
        line1 = 0x8C;
    }
    else
    {
        line0 = 0xC8;
        line1 = 0xCC;
    }
    
    // Bitshift to provide padding for and add control sequence
    column0 = column  << 4;     
    column0 = column0 | 0x8;
    
    // Bitshift to provide padding for and add control sequence
    column1 = column  << 4;
    column1 = column1 | 0xC;
    
    // Select line on display
    LCD_Write_Byte(line0);
    LCD_Write_Byte(line0);
    LCD_Write_Byte(line1);
    LCD_Write_Byte(line0);
    
    
    // Select column on display
    LCD_Write_Byte(column0);
    LCD_Write_Byte(column0);
    LCD_Write_Byte(column1);
    LCD_Write_Byte(column0);
}

void LCD_Clear_Display()
{
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0xC);
    LCD_Write_Byte(0x8);
    LCD_Write_Byte(0x18);
    LCD_Write_Byte(0x18);
    LCD_Write_Byte(0x1C);
    LCD_Write_Byte(0x18);
    
}

void LCD_Draw_Display(uint8 type, uint8 prefix, float data)
{
    // Type 
    // 1 = VAC
    // 2 = A
    // 4 = Omega
    
    // Prefix
    // 5 = mu
    // 6 = m
    // 7 = k
    
    //LCD_Clear_Display();
    
    double  digits      = 0;
    double  decimals    = 0;
    uint8   numOfSpaces = 0;
    
    // Split float into digits and decimals
    decimals = modf(data, &digits) * 10 + 0.500001;
    
    // Set position based on number of digits
    if(digits == 0)
        numOfSpaces = 2;
    else if(digits <= 10)
        numOfSpaces = 2;
    else if(digits <= 100)
        numOfSpaces = 1;
    else if(digits <= 1000)
        numOfSpaces = 0;
    
    LCD_Set_Position(0, 4);
    
    for(uint8 x = numOfSpaces; x > 0; x--)
        LCD_Write_Symbol(0);
    
    if(digits == 0 && decimals < 0.5)
    {
        // Write measurement value
        LCD_Write_Number(0);
        LCD_Write_Symbol(8);                // ,
        LCD_Write_Digit(0);   
    }
    else if(digits == 0 && decimals >= 0.5)
    {
        // Write measurement value
        LCD_Write_Number(0);
        LCD_Write_Symbol(8);                // ,
        LCD_Write_Digit(1); 
    }
    else
    {        
        // Write measurement value
        LCD_Write_Number((int) digits);
        LCD_Write_Symbol(8);                // ,
        LCD_Write_Digit((int) decimals);
    }
    
    // Write prefix and unit
    LCD_Set_Position(0, 10);
    LCD_Write_Symbol(prefix);
    
    // Write measurement type
    if(type == 1)
    {
        LCD_Write_Symbol(1);            // V
        LCD_Write_Symbol(2);            // A
        LCD_Write_Symbol(9);            // C
    }
    else
        LCD_Write_Symbol(type);
}