/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef I2CDisplay_H
#define I2CDisplay_H

// Prototypes
void LCD_Init();
void LCD_Write_Byte(uint8 data);
void LCD_Write_Digit(uint8 digit);
void LCD_Write_Number(uint16 number);
void LCD_Write_Symbol(uint8 symbol);
void LCD_Set_Position(uint8 line, uint8 column);
void LCD_Clear_Display();
void LCD_Draw_Display(uint8 type, uint8 prefix, float data);

#endif