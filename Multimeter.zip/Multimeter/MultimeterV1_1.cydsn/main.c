
#include "FreeRTOSCode.h"
#include "I2CDisplay.h"

/* RTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"



int main( void )
{  
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	prvHardwareSetup();
    
    // I2C and LCD init
    I2C_Start();
    LCD_Init();
    ADC_DelSig_Start();
    DFB_Start();
    Autorange_Reg_Write(0);
    
    /* Create one of the two tasks. Note that a real application should check
    the return value of the xTaskCreate() call to ensure the task was created
    successfully. */
    xTaskCreate(    vTask1, /* Pointer to the function that implements the task. */
                    "Task 1",/* Text name for the task. This is to facilitate
                            debugging only. */
                    1000, /* Stack depth - small microcontrollers will use much
                            less stack than this. Stack size in words not bytes. */
                    NULL, /* This example does not use the task parameter. 
                            Parameter passed into the task*/
                    3, /* This task will run at priority 1. */
                    NULL ); /* This example does not use the task handle. 
                            Used to pass out the created task's handle.*/
    
    /* Create the other task in exactly the same way and at the same priority. */
    xTaskCreate( vTask2, "Task 2", 1000, NULL, 2, NULL );
    xTaskCreate( vTask3, "Task 3", 1000, NULL, 1, NULL );
    
    
    ADC_DelSig_StartConvert();
    
    
    
    /* Start the scheduler so the tasks start executing. */
    vTaskStartScheduler();
    
    /* If all is well then main() will never reach here as the scheduler will
    now be running the tasks. If main() does reach here then it is likely that
    there was insufficient heap memory available for the idle task to be created.
    Chapter 2 provides more information on heap memory management. */
    for( ;; )
        ;
}
/*---------------------------------------------------------------------------*/
