#include "cytypes.h"
#include "DFB.h"

const uint32 CYCODE DFB_control[] = 
{
    0x25001760u,      0x26000E00u,      0x26801321u,      0x2E140000u,  
    0x2E810000u,      0x6E408000u,      0x6E800000u,      0x6E804000u,  
    0x6E102000u,      0x6E100200u,      0x6E500000u,      0x6E800000u,  
    0x6E804000u,      0x6E800001u,      0x0E100003u,  
};

const uint32 CYCODE DFB_data_a[] = 
{
    0x00000000u,  
};

const uint32 CYCODE DFB_data_b[] = 
{
    0x00000000u,  
};

const uint32 CYCODE DFB_acu[] = 
{
    0x0000001Fu,  
};

const uint32 CYCODE DFB_cfsm[] = 
{
    0x011DF822u,      0x011DF842u,      0x408671C1u,      0x00000000u,  

};

